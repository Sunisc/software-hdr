% HDR Algorithm - Surya P

% loading the images
ldr1 = imread("memorial0061.png");
ldr2 = imread("memorial0062.png");
ldr3 = imread("memorial0063.png");
ldr4 = imread("memorial0064.png");
ldr5 = imread("memorial0065.png");
ldr6 = imread("memorial0066.png");
ldr7 = imread("memorial0067.png");
ldr8 = imread("memorial0068.png");
ldr9 = imread("memorial0069.png");
ldr10 = imread("memorial0070.png");
ldr11 = imread("memorial0071.png");
ldr12 = imread("memorial0072.png");
ldr13 = imread("memorial0073.png");
ldr14 = imread("memorial0074.png");
ldr15 = imread("memorial0075.png");
ldr16 = imread("memorial0076.png");

% part 1

% Simple average
ldrs = cat(4, im2double(ldr1), im2double(ldr2), im2double(ldr3), im2double(ldr4), im2double(ldr5), im2double(ldr6), im2double(ldr7), im2double(ldr8), im2double(ldr9), im2double(ldr10), im2double(ldr11), im2double(ldr12), im2double(ldr13), im2double(ldr14), im2double(ldr15), im2double(ldr16));
exposures = [32, 16, 8, 4, 2, 1, .5, .25, .125, .0625, .03125, .015625, .0078125, .00390625, .001953125, .0009765625]
ldrs_1 = ldrs(:, :, :, 1) ./ exposures(1)
ldrs_2 = ldrs(:, :, :, 2) ./ exposures(2)
ldrs_3 = ldrs(:, :, :, 3) ./ exposures(3);
ldrs_4 = ldrs(:, :, :, 4) ./ exposures(4)
ldrs_5 = ldrs(:, :, :, 5) ./ exposures(5)
ldrs_6 = ldrs(:, :, :, 6) ./ exposures(6);
ldrs_7 = ldrs(:, :, :, 7) ./ exposures(7)
ldrs_8 = ldrs(:, :, :, 8) ./ exposures(8);
ldrs_9 = ldrs(:, :, :, 9) ./ exposures(9)
ldrs_10 = ldrs(:, :, :, 10) ./ exposures(10)
ldrs_11 = ldrs(:, :, :, 11) ./ exposures(11)
ldrs_12 = ldrs(:, :, :, 12) ./ exposures(12)
ldrs_13 = ldrs(:, :, :, 13) ./ exposures(13)
ldrs_14 = ldrs(:, :, :, 14) ./ exposures(14)
ldrs_15 = ldrs(:, :, :, 15) ./ exposures(15)
ldrs_16 = ldrs(:, :, :, 16) ./ exposures(16)

avg = ((ldrs_1 + ldrs_2 + ldrs_3 + ldrs_4 + ldrs_5 + ldrs_6 + ldrs_7 + ldrs_8 + ldrs_9 + ldrs_10 + ldrs_11 + ldrs_12 + ldrs_13 + ldrs_14 + ldrs_15 + ldrs_16) / 16)

result = tonemap(avg, 'AdjustSaturation', 3.0);
imshow(result)

% Weighted average
% Do the same thing but remove the outliers first.
% method 1
ldrw_1 = im2double(ldr1);
ldrw_1(im2double(ldr1)>.98) = 0;
ldrw_1(im2double(ldr1)<.02) = 0;
ldrw_1 = ldrw_1 ./ exposures(1);

ldrw_2 = im2double(ldr2);
ldrw_2(im2double(ldr2)>.98) = 0;
ldrw_2(im2double(ldr2)<.02) = 0;
ldrw_2 = ldrw_2 ./ exposures(2);

ldrw_3 = im2double(ldr3);
ldrw_3(im2double(ldr3)>.98) = 0;
ldrw_3(im2double(ldr3)<.02) = 0;
ldrw_3 = ldrw_3 ./ exposures(3);

ldrw_4 = im2double(ldr4);
ldrw_4(im2double(ldr4)>.98) = 0;
ldrw_4(im2double(ldr4)<.02) = 0;
ldrw_4 = ldrw_4 ./ exposures(4);

ldrw_5 = im2double(ldr5);
ldrw_5(im2double(ldr5)>.98) = 0;
ldrw_5(im2double(ldr5)<.02) = 0;
ldrw_5 = ldrw_5 ./ exposures(5);

ldrw_6 = im2double(ldr6);
ldrw_6(im2double(ldr6)>.98) = 0;
ldrw_6(im2double(ldr6)<.02) = 0;
ldrw_6 = ldrw_6 ./ exposures(6);

ldrw_7 = im2double(ldr7);
ldrw_7(im2double(ldr7)>.98) = 0;
ldrw_7(im2double(ldr7)<.02) = 0;
ldrw_7 = ldrw_7 ./ exposures(7);

ldrw_8 = im2double(ldr8);
ldrw_8(im2double(ldr8)>.98) = 0;
ldrw_8(im2double(ldr8)<.02) = 0;
ldrw_8 = ldrw_8 ./ exposures(8);

ldrw_9 = im2double(ldr9);
ldrw_9(im2double(ldr9)>.98) = 0;
ldrw_9(im2double(ldr9)<.02) = 0;
ldrw_9 = ldrw_9 ./ exposures(9);

ldrw_10 = im2double(ldr10);
ldrw_10(im2double(ldr10)>.98) = 0;
ldrw_10(im2double(ldr10)<.02) = 0;
ldrw_10 = ldrw_10 ./ exposures(10);

ldrw_11 = im2double(ldr11);
ldrw_11(im2double(ldr11)>.98) = 0;
ldrw_11(im2double(ldr11)<.02) = 0;
ldrw_11 = ldrw_11 ./ exposures(11);

ldrw_12 = im2double(ldr12);
ldrw_12(im2double(ldr12)>.98) = 0;
ldrw_12(im2double(ldr12)<.02) = 0;
ldrw_12 = ldrw_12 ./ exposures(12);

ldrw_13 = im2double(ldr13);
ldrw_13(im2double(ldr13)>.98) = 0;
ldrw_13(im2double(ldr13)<.02) = 0;
ldrw_13 = ldrw_13./ exposures(13);

ldrw_14 = im2double(ldr14);
ldrw_14(im2double(ldr14)>.98) = 0;
ldrw_14(im2double(ldr14)<.02) = 0;
ldrw_14 = ldrw_14 ./ exposures(14);

ldrw_15 = im2double(ldr15);
ldrw_15(im2double(ldr15)>.98) = 0;
ldrw_15(im2double(ldr15)<.02) = 0;
ldrw_15 = ldrw_15 ./ exposures(15);

ldrw_16 = im2double(ldr16);
ldrw_16(im2double(ldr16)>.98) = 0;
ldrw_16(im2double(ldr16)<.02) = 0;
ldrw_16 = ldrw_16 ./ exposures(16);

imshow(ldrw_5)

wavg = ((ldrw_1 + ldrw_2 + ldrw_3 + ldrw_4 + ldrw_5 + ldrw_6 + ldrw_7 + ldrw_8 + ldrw_9 + ldrw_10 + ldrw_11 + ldrw_12 + ldrw_13 + ldrw_14 + ldrw_15 + ldrw_16) / 16)
result = tonemap(wavg, 'AdjustSaturation', 3.0);
imshow(result)


% method 2, doesn't seem to work, keep getting a blue image.
% I was trying to find the weight and multiply it bythe standarized pixel
% value and then normalize it with the exposure. I ended up getting a blue
% image. Which was pretty cool.
ldrw_1 = ((double(128-abs(ldr1-128)) .* double(ldr1)) ./ 128 ) ./ exposures(1)
ldrw_2 = ((double(128-abs(ldr1-128)) .* double(ldr2)) ./ 128 ) ./ exposures(2)
ldrw_3 = ((double(128-abs(ldr1-128)) .* double(ldr3)) ./ 128 ) ./ exposures(3)
ldrw_4 = ((double(128-abs(ldr1-128)) .* double(ldr4)) ./ 128 ) ./ exposures(4)
ldrw_5 = ((double(128-abs(ldr1-128)) .* double(ldr5)) ./ 128 ) ./ exposures(5)
ldrw_6 = ((double(128-abs(ldr1-128)) .* double(ldr6)) ./ 128 ) ./ exposures(6)
ldrw_7 = ((double(128-abs(ldr1-128)) .* double(ldr7)) ./ 128 ) ./ exposures(7)
ldrw_8 = ((double(128-abs(ldr1-128)) .* double(ldr8)) ./ 128 ) ./ exposures(8)
ldrw_9 = ((double(128-abs(ldr1-128)) .* double(ldr9)) ./ 128 ) ./ exposures(9)
ldrw_10 = ((double(128-abs(ldr1-128)) .* double(ldr10)) ./ 128 ) ./ exposures(10)
ldrw_11 = ((double(128-abs(ldr1-128)) .* double(ldr11)) ./ 128 ) ./ exposures(11)
ldrw_12 = ((double(128-abs(ldr1-128)) .* double(ldr12)) ./ 128 ) ./ exposures(12)
ldrw_13 = ((double(128-abs(ldr1-128)) .* double(ldr13)) ./ 128 ) ./ exposures(13)
ldrw_14 = ((double(128-abs(ldr1-128)) .* double(ldr14)) ./ 128 ) ./ exposures(14)
ldrw_15 = ((double(128-abs(ldr1-128)) .* double(ldr15)) ./ 128 ) ./ exposures(15)
ldrw_16 = ((double(128-abs(ldr1-128)) .* double(ldr16)) ./ 128 ) ./ exposures(16)

imshow(ldrw_1)

wavg = ((ldrw_1 + ldrw_2 + ldrw_3 + ldrw_4 + ldrw_5 + ldrw_6 + ldrw_7 + ldrw_8 + ldrw_9 + ldrw_10 + ldrw_11 + ldrw_12 + ldrw_13 + ldrw_14 + ldrw_15 + ldrw_16) / 16)
result = tonemap(wavg, 'AdjustSaturation', 3.0);
imshow(result)

% Median
% remove the outliers first and then normalize the image
ldrw_1 = im2double(ldr1);
ldrw_1(im2double(ldr1)>.98) = 0;
ldrw_1(im2double(ldr1)<.02) = 0;
ldrw_1 = ldrw_1 ./ exposures(1);

ldrw_2 = im2double(ldr2);
ldrw_2(im2double(ldr2)>.98) = 0;
ldrw_2(im2double(ldr2)<.02) = 0;
ldrw_2 = ldrw_2 ./ exposures(2);

ldrw_3 = im2double(ldr3);
ldrw_3(im2double(ldr3)>.98) = 0;
ldrw_3(im2double(ldr3)<.02) = 0;
ldrw_3 = ldrw_3 ./ exposures(3);

ldrw_4 = im2double(ldr4);
ldrw_4(im2double(ldr4)>.98) = 0;
ldrw_4(im2double(ldr4)<.02) = 0;
ldrw_4 = ldrw_4 ./ exposures(4);

ldrw_5 = im2double(ldr5);
ldrw_5(im2double(ldr5)>.98) = 0;
ldrw_5(im2double(ldr5)<.02) = 0;
ldrw_5 = ldrw_5 ./ exposures(5);

ldrw_6 = im2double(ldr6);
ldrw_6(im2double(ldr6)>.98) = 0;
ldrw_6(im2double(ldr6)<.02) = 0;
ldrw_6 = ldrw_6 ./ exposures(6);

ldrw_7 = im2double(ldr7);
ldrw_7(im2double(ldr7)>.98) = 0;
ldrw_7(im2double(ldr7)<.02) = 0;
ldrw_7 = ldrw_7 ./ exposures(7);

ldrw_8 = im2double(ldr8);
ldrw_8(im2double(ldr8)>.98) = 0;
ldrw_8(im2double(ldr8)<.02) = 0;
ldrw_8 = ldrw_8 ./ exposures(8);

ldrw_9 = im2double(ldr9);
ldrw_9(im2double(ldr9)>.98) = 0;
ldrw_9(im2double(ldr9)<.02) = 0;
ldrw_9 = ldrw_9 ./ exposures(9);

ldrw_10 = im2double(ldr10);
ldrw_10(im2double(ldr10)>.98) = 0;
ldrw_10(im2double(ldr10)<.02) = 0;
ldrw_10 = ldrw_10 ./ exposures(10);

ldrw_11 = im2double(ldr11);
ldrw_11(im2double(ldr11)>.98) = 0;
ldrw_11(im2double(ldr11)<.02) = 0;
ldrw_11 = ldrw_11 ./ exposures(11);

ldrw_12 = im2double(ldr12);
ldrw_12(im2double(ldr12)>.98) = 0;
ldrw_12(im2double(ldr12)<.02) = 0;
ldrw_12 = ldrw_12 ./ exposures(12);

ldrw_13 = im2double(ldr13);
ldrw_13(im2double(ldr13)>.98) = 0;
ldrw_13(im2double(ldr13)<.02) = 0;
ldrw_13 = ldrw_13./ exposures(13);

ldrw_14 = im2double(ldr14);
ldrw_14(im2double(ldr14)>.98) = 0;
ldrw_14(im2double(ldr14)<.02) = 0;
ldrw_14 = ldrw_14 ./ exposures(14);

ldrw_15 = im2double(ldr15);
ldrw_15(im2double(ldr15)>.98) = 0;
ldrw_15(im2double(ldr15)<.02) = 0;
ldrw_15 = ldrw_15 ./ exposures(15);

ldrw_16 = im2double(ldr16);
ldrw_16(im2double(ldr16)>.98) = 0;
ldrw_16(im2double(ldr16)<.02) = 0;
ldrw_16 = ldrw_16 ./ exposures(16);

X(:, :, :, 1) = ldrw_1;
X(:, :, :, 2) = ldrw_2;
X(:, :, :, 3) = ldrw_3;
X(:, :, :, 4) = ldrw_4;
X(:, :, :, 5) = ldrw_5;
X(:, :, :, 6) = ldrw_6;
X(:, :, :, 7) = ldrw_7;
X(:, :, :, 8) = ldrw_8;
X(:, :, :, 9) = ldrw_9;
X(:, :, :, 10) = ldrw_10;
X(:, :, :, 11) = ldrw_11;
X(:, :, :, 12) = ldrw_12;
X(:, :, :, 13) = ldrw_13;
X(:, :, :, 14) = ldrw_14;
X(:, :, :, 15) = ldrw_15;
X(:, :, :, 16) = ldrw_16;

imshow(ldrw_15)
Y=median(X,4); % choose the median exposure value
imshow(Y)
result = tonemap(im2double(Y), 'AdjustSaturation', 3.0);
imshow(result)

% Non-saturating highest exposure, 90% of 255 = 229, or .9 if using
% im2double

temp = ldr5;
ldrs2 = cat(4, ldr1, ldr2, ldr3, ldr4, ldr5, ldr6, ldr7, ldr8, ldr9, ldr10, ldr11, ldr12, ldr13, ldr14, ldr15, ldr16);

limit = 216; %85% of 255
% basically loop through the color channels and then each pixel and see
% which one is closest to the limit and then take that one and normalize it
% and put it into an image.
for c = 1:3
    for i = 1:768
        for j = 1:512
            min = 10000;
            for k = 1:16
                if ldrs2(i, j, c, k) < limit
                    tmp = limit - ldrs2(i, j, c, k);
                    if tmp < min
                        min = tmp;
                        temp(i, j, c) = ldrs2(i, j, c, k) ./ exposures(k);
                    end
                end 
            end
        end
    end
end
result = tonemap(im2double(temp), 'AdjustSaturation', 3.0);
imshow(result)


% part 2
% get some basic variables set up
w = @(z) double(128-abs(z-128));
reds = [];
greens = [];
blues = [];

% choose a 100 random locations, doesn't matter what channel you use since
% dimensions same
locations = randperm(numel(ldr1(:, :, 1)), 100);

%extract individual colors and stack them into a 100x16
for j = 1:16
    l = squeeze(ldrs2(:, :, :, j))
    redC = l(:, :, 1);
    greenC = l(:, :, 2);
    blueC = l(:, :, 3);
    redVals = redC(locations);
    greenVals = greenC(locations);
    blueVals = blueC(locations);
    reds = [reds ; redVals];
    greens = [greens ; greenVals];
    blues = [blues ; blueVals];
end

%transpose the matrix
reds = reds';
greens = greens';
blues = blues';

%use exposure time
b = [0.03125, 0.0625, 0.125, .25, .5, 1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024];
b = log(b);
e = log(exposures);

%save the function outputs
lam = 31;
[greenSolve, gLE] = gsolve(greens, e, lam, w);
[redSolve, rLE] = gsolve(reds, e, lam, w);
[blueSolve, bLE] = gsolve(blues, e, lam, w);

%plot the graphs
plot(squeeze(greenSolve), 1:256, 'color', 'g');
hold on

title('green exposure');
xlabel('log exposure');
ylabel('pixel');

%use equation 6 to extract individual radiances for each channel
greenRadiances = []
for i = 1:255
    n = 0.0;
    d = 0.0;
    for j = 1:16
        n = n + (w(i) * (greenSolve(i)-e(j)));
        d = d + (w(i));
    end
    greenRadiances = [greenRadiances exp(n/d)];
end
redRadiances = []
for i = 1:255
    n = 0.0;
    d = 0.0;
    for j = 1:16
        n = n + (w(i) * (redSolve(i)-e(j)));
        d = d + (w(i));
    end
    redRadiances = [redRadiances exp(n/d)];
end
blueRadiances = []
for i = 1:255
    n = 0.0;
    d = 0.0;
    for j = 1:16
        n = n + (w(i) * (blueSolve(i)-e(j)));
        d = d + (w(i));
    end
    blueRadiances = [blueRadiances exp(n/d)];
end

%map the radiance values onto each individual color channel for every
%exposure level. 
% I use this for the highest non saturating method.
ldrs3 = ldrs2
for m = 1:16
    for i = 1:768
        for j = 1:512
            if ldrs3(i, j, 1, m) == 0
                ldrs3(i,j,1,m) = 0;
            else
                ldrs3(i, j, 1,m) = redRadiances(ldrs2(i, j, 1, m)) * ldrs2(i, j, 1, m);
            end

            if ldrs3(i, j, 2,m) == 0
                ldrs3(i,j,2,m) = 0;
            else
                ldrs3(i, j,2,m) = greenRadiances(ldrs2(i, j, 2, m)) * ldrs2(i, j, 2, m);
            end

            if ldrs3(i, j, 3,m) == 0
                ldrs3(i,j,3,m) = 0;
            else
                ldrs3(i, j, 3,m) = blueRadiances(ldrs2(i, j, 3, m)) * ldrs2(i, j, 3, m);
            end
        end
    end
end

%regular mapping for the simple average HDR (the main one)
ldrs3 = ldrs2
for m = 1:16
    for i = 1:768
        for j = 1:512
            if ldrs3(i, j, 1, m) == 0
                ldrs3(i,j,1,m) = 0;
            else
                ldrs3(i, j, 1,m) = redRadiances(ldrs2(i, j, 1, m));
            end

            if ldrs3(i, j, 2,m) == 0
                ldrs3(i,j,2,m) = 0;
            else
                ldrs3(i, j,2,m) = greenRadiances(ldrs2(i, j, 2, m));
            end

            if ldrs3(i, j, 3,m) == 0
                ldrs3(i,j,3,m) = 0;
            else
                ldrs3(i, j, 3,m) = blueRadiances(ldrs2(i, j, 3, m));
            end
        end
    end
end
ldrs3 = double(ldrs3)

%two methods for HDR calculation. Regular weighted average
%hdr image by adding all of the radiances
avg = ((ldrs3(:, :, :, 1) + ldrs3(:, :, :, 2) + ldrs3(:, :, :, 3) + ldrs3(:, :, :, 4) + ldrs3(:, :, :, 5) + ldrs3(:, :, :, 6) + ldrs3(:, :, :, 7) + ldrs3(:, :, :, 8) + ldrs3(:, :, :, 9) + ldrs3(:, :, :, 10) + ldrs3(:, :, :, 11) + ldrs3(:, :, :, 12) + ldrs3(:, :, :, 13) + ldrs3(:, :, :, 14) + ldrs3(:, :, :, 15) + ldrs3(:, :, :, 16))/16)
result = tonemap(avg, 'AdjustSaturation', 3.0);
imshow(result)

%I went ahead and used the highest non saturating method since it gave me
%the best results. I remember you mentioning in the lecture to continue
%using the method from the naive methods once you've calculated the
%radiances

limit = 216; %85% of 255
% basically loop through the color channels and then each pixel and see
% which one is closest to the limit and then take that one and normalize it
% and put it into an image.

for c = 1:3
    for i = 1:768
        for j = 1:512
            min = 10000;
            for k = 1:16
                if ldrs3(i, j, c, k) < limit
                    tmp = limit - ldrs3(i, j, c, k);
                    if tmp < min
                        min = tmp;
                        temp(i, j, c) = ldrs3(i, j, c, k) ./ exposures(k);
                    end
                end 
            end
        end
    end
end
result = tonemap(im2double(temp), 'AdjustSaturation', 3.0);
imshow(result)


